package dev.sushi.camera;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** Native Android dark camera UI; camera work lives on CameraEngine's own HandlerThread. */
public final class MainActivity extends Activity implements CameraEngine.Callbacks {
    private static final int INK = Color.rgb(9, 11, 16);
    private static final int PANEL = Color.argb(244, 15, 18, 26);
    private static final int PILL = Color.rgb(31, 37, 49);
    private static final int SKY = Color.rgb(180, 220, 255);
    private static final int OFFWHITE = Color.rgb(236, 243, 251);
    private static final int MUTED = Color.rgb(147, 158, 175);
    private static final int CORAL = Color.rgb(255, 83, 96);

    private FrameLayout root;
    private TextureView texture;
    private GridLines grid;
    private CameraEngine engine;
    private TextView status, lensLabel, modePhoto, modeVideo, shutterButton, zoomValue, recordMark, galleryText;
    private TextView isoChip, shutterChip, focusChip, wbChip, evChip, processingChip;
    private ImageView galleryImage;
    private SeekBar zoomSeek;
    private View zoomRow;
    private boolean isVideo = false;
    private boolean recording = false;
    private boolean showGrid = false;
    private Uri lastCapture;
    private int lastCaptureIsVideo = 0;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private ScaleGestureDetector pinch;
    private long recordStartMs;
    private final Runnable updateTimer = new Runnable() {
        @Override public void run() {
            if (!recording) return;
            long elapsed = (android.os.SystemClock.elapsedRealtime() - recordStartMs) / 1000L;
            status.setText(String.format(Locale.US, "REC  %02d:%02d", elapsed / 60, elapsed % 60));
            mainHandler.postDelayed(this, 500);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        String action = getIntent().getAction();
        isVideo = MediaStore.ACTION_VIDEO_CAPTURE.equals(action) || MediaStore.INTENT_ACTION_VIDEO_CAMERA.equals(action);
        buildUi();
        requestCameraPermission();
    }

    @Override protected void onResume() {
        super.onResume();
        if (hasCameraPermission()) startEngineIfReady();
    }

    @Override protected void onPause() {
        if (engine != null) { saveSettings(engine); engine.stop(); engine = null; }
        recording = false;
        mainHandler.removeCallbacks(updateTimer);
        super.onPause();
    }


    private void restoreSettings(CameraEngine e) {
        SharedPreferences p = getSharedPreferences("capture_settings", MODE_PRIVATE);
        e.iso = p.getInt("iso", 0);
        e.shutterNs = p.getLong("shutter", 0);
        e.focusDistance = p.getFloat("focus", -1f);
        e.wbTemperature = p.getInt("wb", 0);
        e.exposure = p.getInt("ev", 0);
        e.stabilize = p.getBoolean("stabilize", true);
        e.naturalProcessing = p.getBoolean("natural", false);
        e.includeAudio = p.getBoolean("audio", true);
        e.audioChannels = p.getInt("channels", 2);
        e.preferredAudioType = p.getInt("audio_device", 0);
        e.frameRate = p.getInt("fps", 30);
        e.width = p.getInt("width", 1920);
        e.height = p.getInt("height", 1080);
        e.bitrate = p.getInt("bitrate", 16000000);
        e.hevc = p.getBoolean("hevc", false);
        e.maximumPhotoResolution = p.getBoolean("max_photo", false);
        showGrid = p.getBoolean("grid", false);
        if (grid != null) grid.setVisibility(showGrid ? View.VISIBLE : View.GONE);
    }

    private void saveSettings(CameraEngine e) {
        getSharedPreferences("capture_settings", MODE_PRIVATE).edit()
                .putInt("iso", e.iso).putLong("shutter", e.shutterNs)
                .putFloat("focus", e.focusDistance).putInt("wb", e.wbTemperature)
                .putInt("ev", e.exposure).putBoolean("stabilize", e.stabilize)
                .putBoolean("natural", e.naturalProcessing).putBoolean("audio", e.includeAudio)
                .putInt("channels", e.audioChannels).putInt("audio_device", e.preferredAudioType)
                .putInt("fps", e.frameRate).putInt("width", e.width).putInt("height", e.height)
                .putInt("bitrate", e.bitrate).putBoolean("hevc", e.hevc)
                .putBoolean("max_photo", e.maximumPhotoResolution).putBoolean("grid", showGrid)
                .apply();
    }

    private boolean hasCameraPermission() {
        return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestCameraPermission() {
        if (!hasCameraPermission()) {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, 10);
        } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            // Audio permission is optional: video will be silent if not granted.
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 11);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (hasCameraPermission()) startEngineIfReady();
        else new AlertDialog.Builder(this).setTitle("Camera permission needed")
                .setMessage("Sushi Camera needs access to the camera to show a preview and capture photos.")
                .setPositiveButton("Grant access", (d, w) -> requestCameraPermission())
                .setNegativeButton("Exit", (d, w) -> finish()).show();
    }

    private void startEngineIfReady() {
        if (engine != null || !hasCameraPermission() || texture == null || !texture.isAvailable()) return;
        engine = new CameraEngine(this, texture, this);
        restoreSettings(engine);
        engine.start();
        updateControlLabels();
    }

    private int dp(float x) { return Math.round(x * getResources().getDisplayMetrics().density); }

    private GradientDrawable background(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private GradientDrawable outline(int fill, int stroke, int radius) {
        GradientDrawable d = background(fill, radius);
        d.setStroke(dp(1.5f), stroke); return d;
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size); v.setTextColor(color);
        v.setGravity(Gravity.CENTER);
        if (bold) v.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD));
        return v;
    }

    private LinearLayout row(int gravity) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(gravity); r.setOrientation(LinearLayout.HORIZONTAL); return r;
    }
    private LinearLayout column() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); return c;
    }
    private LinearLayout.LayoutParams lp(int w, int h, int margin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
        p.setMargins(dp(margin), 0, dp(margin), 0); return p;
    }

    private TextView action(String text, int width, int height, View.OnClickListener listener) {
        TextView button = label(text, 14, OFFWHITE, true);
        button.setBackground(background(PILL, 16));
        button.setClickable(true);
        button.setOnClickListener(listener);
        button.setMinWidth(dp(width)); button.setMinHeight(dp(height));
        return button;
    }

    private void buildUi() {
        root = new FrameLayout(this); root.setBackgroundColor(INK);
        setContentView(root);
        texture = new TextureView(this);
        root.addView(texture, new FrameLayout.LayoutParams(-1, -1));
        grid = new GridLines(); root.addView(grid, new FrameLayout.LayoutParams(-1, -1));
        grid.setVisibility(showGrid ? View.VISIBLE : View.GONE);
        pinch = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                if (engine == null) return false;
                engine.zoom = Math.max(1f, Math.min(engine.getMaxZoom(), engine.zoom * detector.getScaleFactor()));
                zoomSeek.setProgress(Math.min(100, Math.round((engine.zoom - 1) / (engine.getMaxZoom() - 1 + .0001f) * 100)));
                updateZoomLabel(); engine.refreshControls();
                return true;
            }
        });
        texture.setOnTouchListener((v, event) -> {
            pinch.onTouchEvent(event);
            if (event.getAction() == MotionEvent.ACTION_UP && !pinch.isInProgress() && engine != null) engine.focusOnce();
            return true;
        });
        texture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(android.graphics.SurfaceTexture s, int w, int h) { startEngineIfReady(); }
            @Override public void onSurfaceTextureSizeChanged(android.graphics.SurfaceTexture s, int w, int h) { }
            @Override public boolean onSurfaceTextureDestroyed(android.graphics.SurfaceTexture s) { return true; }
            @Override public void onSurfaceTextureUpdated(android.graphics.SurfaceTexture s) { }
        });

        LinearLayout header = column();
        header.setPadding(dp(14), dp(12), dp(14), dp(16));
        header.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xF5000000, 0x55000000, 0x00000000}));
        FrameLayout.LayoutParams headLp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        root.addView(header, headLp);
        LinearLayout h1 = row(Gravity.CENTER_VERTICAL);
        LinearLayout titleBox = column();
        TextView brand = label("SUSHI  /  CAMERA", 17, OFFWHITE, true);
        brand.setGravity(Gravity.START);
        titleBox.addView(brand);
        TextView tagline = label("PRO CAPTURE  •  CAMERA2", 9, SKY, true);
        tagline.setGravity(Gravity.START); tagline.setLetterSpacing(.16f);
        titleBox.addView(tagline);
        h1.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));
        TextView settings = action("⚙", 46, 44, v -> showSettings());
        settings.setTextSize(24);
        settings.setContentDescription("Camera settings");
        h1.addView(settings, lp(46, 44, 3));
        header.addView(h1);
        LinearLayout h2 = row(Gravity.CENTER_VERTICAL);
        h2.setPadding(0, dp(15), 0, 0);
        lensLabel = action("LENS  •  --", 130, 38, v -> showLensDialog());
        lensLabel.setTextSize(12); lensLabel.setTextColor(SKY);
        h2.addView(lensLabel, new LinearLayout.LayoutParams(0, dp(38), 1));
        TextView flip = action("⇄", 46, 38, v -> { if (engine != null) engine.toggleFrontRear(); });
        flip.setTextSize(23); flip.setContentDescription("Switch front and rear camera");
        h2.addView(flip, lp(46, 38, 4));
        TextView torch = action("⚡", 46, 38, v -> {
            if (engine != null) { engine.torch = !engine.torch; engine.refreshControls(); }
        });
        torch.setContentDescription("Toggle torch"); h2.addView(torch, lp(46, 38, 4));
        header.addView(h2);

        LinearLayout footer = column();
        footer.setPadding(dp(14), dp(17), dp(14), dp(22));
        footer.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x00111620, 0xEE0B0E15, 0xFF090B10}));
        FrameLayout.LayoutParams footLp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        root.addView(footer, footLp);

        status = label("INITIALIZING CAMERA", 11, SKY, true);
        status.setLetterSpacing(.16f);
        footer.addView(status, new LinearLayout.LayoutParams(-1, dp(25)));

        LinearLayout zoomContainer = row(Gravity.CENTER_VERTICAL);
        zoomContainer.setPadding(dp(10), 0, dp(10), 0);
        zoomValue = label("1.0×", 14, OFFWHITE, true);
        zoomContainer.addView(zoomValue, lp(53, 36, 0));
        zoomSeek = new SeekBar(this);
        zoomSeek.setMax(100); zoomSeek.setProgress(0);
        zoomSeek.setProgressTintList(android.content.res.ColorStateList.valueOf(SKY));
        zoomSeek.setThumbTintList(android.content.res.ColorStateList.valueOf(OFFWHITE));
        zoomContainer.addView(zoomSeek, new LinearLayout.LayoutParams(0, dp(42), 1));
        zoomSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int progress, boolean user) {
                if (!user || engine == null) return;
                engine.zoom = 1 + (engine.getMaxZoom() - 1) * progress / 100f;
                updateZoomLabel(); engine.refreshControls();
            }
            @Override public void onStartTrackingTouch(SeekBar b) { }
            @Override public void onStopTrackingTouch(SeekBar b) { }
        });
        zoomRow = zoomContainer;
        footer.addView(zoomContainer);

        HorizontalScrollView manualScroll = new HorizontalScrollView(this);
        manualScroll.setHorizontalScrollBarEnabled(false); manualScroll.setFillViewport(false);
        LinearLayout manualRow = row(Gravity.CENTER);
        manualRow.setPadding(0, dp(8), 0, dp(9));
        isoChip = controlChip("ISO", "AUTO", () -> chooseIso());
        shutterChip = controlChip("SHUTTER", "AUTO", () -> chooseShutter());
        focusChip = controlChip("FOCUS", "AUTO", () -> chooseFocus());
        wbChip = controlChip("WB", "AUTO", () -> chooseWb());
        evChip = controlChip("EV", "0", () -> chooseEv());
        processingChip = controlChip("NR/EDGE", "AUTO", () -> {
            if (engine == null) return;
            engine.naturalProcessing = !engine.naturalProcessing;
            engine.refreshControls(); updateControlLabels();
        });
        for (TextView v : Arrays.asList(isoChip, shutterChip, focusChip, wbChip, evChip, processingChip))
            manualRow.addView(v, lp(93, 59, 3));
        manualScroll.addView(manualRow); footer.addView(manualScroll);

        LinearLayout modes = row(Gravity.CENTER);
        modePhoto = label("PHOTO", 13, OFFWHITE, true);
        modeVideo = label("VIDEO", 13, MUTED, true);
        modePhoto.setLetterSpacing(.14f); modeVideo.setLetterSpacing(.14f);
        modePhoto.setOnClickListener(v -> setVideoMode(false));
        modeVideo.setOnClickListener(v -> setVideoMode(true));
        modes.addView(modePhoto, lp(84, 43, 8)); modes.addView(modeVideo, lp(84, 43, 8));
        footer.addView(modes);

        FrameLayout capturePanel = new FrameLayout(this);
        LinearLayout.LayoutParams captureLp = new LinearLayout.LayoutParams(-1, dp(96));
        footer.addView(capturePanel, captureLp);
        galleryImage = new ImageView(this);
        galleryImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        galleryImage.setBackground(outline(PILL, 0xFF475366, 12));
        galleryImage.setClipToOutline(true);
        FrameLayout.LayoutParams galleryLp = new FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER_VERTICAL | Gravity.START);
        galleryLp.leftMargin = dp(14);
        capturePanel.addView(galleryImage, galleryLp);
        galleryText = label("GALLERY", 8, OFFWHITE, true);
        FrameLayout.LayoutParams gTextLp = new FrameLayout.LayoutParams(dp(60), dp(19), Gravity.BOTTOM | Gravity.START);
        gTextLp.leftMargin = dp(11);
        capturePanel.addView(galleryText, gTextLp);
        View.OnClickListener onGallery = v -> showLastCapture();
        galleryImage.setOnClickListener(onGallery); galleryText.setOnClickListener(onGallery);

        shutterButton = label("", 27, INK, true);
        shutterButton.setContentDescription("Take photo or record video");
        shutterButton.setBackground(outline(OFFWHITE, SKY, 999));
        FrameLayout.LayoutParams bLp = new FrameLayout.LayoutParams(dp(76), dp(76), Gravity.CENTER);
        capturePanel.addView(shutterButton, bLp);
        shutterButton.setOnClickListener(v -> capture());
        recordMark = label("●", 22, CORAL, true);
        FrameLayout.LayoutParams mLp = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER_VERTICAL | Gravity.END);
        mLp.rightMargin = dp(20);
        capturePanel.addView(recordMark, mLp);
        recordMark.setVisibility(View.INVISIBLE);
        updateModeButtons();
    }

    private TextView controlChip(String name, String value, Runnable onClick) {
        TextView chip = label(name + "\n" + value, 11, OFFWHITE, true);
        chip.setBackground(background(PANEL, 12));
        chip.setLineSpacing(dp(3), 1f);
        chip.setOnClickListener(v -> { if (!recording) onClick.run(); });
        chip.setContentDescription(name + " setting");
        return chip;
    }

    private void updateZoomLabel() {
        if (engine != null && zoomValue != null) zoomValue.setText(String.format(Locale.US, "%.1f×", engine.zoom));
    }
    private void updateModeButtons() {
        modePhoto.setTextColor(isVideo ? MUTED : OFFWHITE);
        modeVideo.setTextColor(isVideo ? OFFWHITE : MUTED);
        shutterButton.setBackground(outline(isVideo ? CORAL : OFFWHITE, SKY, 999));
        shutterButton.setText(recording ? "■" : "");
        shutterButton.setTextColor(OFFWHITE);
        recordMark.setVisibility(recording ? View.VISIBLE : View.INVISIBLE);
    }
    private void setVideoMode(boolean video) {
        if (recording || (engine != null && engine.isRecording())) return;
        isVideo = video; updateModeButtons();
        status.setText(isVideo ? "VIDEO  ·  SDR 8-BIT" : "PHOTO  ·  JPEG");
    }

    private void capture() {
        if (engine == null) { toast("Camera is not ready"); return; }
        Intent launched = getIntent();
        Uri output = null;
        try { output = launched.getParcelableExtra(MediaStore.EXTRA_OUTPUT); } catch (Exception ignored) { }
        if (isVideo) {
            if (recording) engine.stopVideo();
            else engine.startVideo(MediaStore.ACTION_VIDEO_CAPTURE.equals(launched.getAction()) ? output : null);
        } else {
            engine.takePhoto(MediaStore.ACTION_IMAGE_CAPTURE.equals(launched.getAction()) ? output : null);
        }
    }

    private void updateControlLabels() {
        if (engine == null) return;
        isoChip.setText("ISO\n" + (engine.iso == 0 ? "AUTO" : engine.iso));
        shutterChip.setText("SHUTTER\n" + (engine.shutterNs == 0 ? "AUTO" :
                "1/" + Math.round(1_000_000_000d / engine.shutterNs)));
        focusChip.setText("FOCUS\n" + (engine.focusDistance < 0 ? "AUTO" :
                String.format(Locale.US, "%.1fD", engine.focusDistance)));
        wbChip.setText("WHITE BAL.\n" + (engine.wbTemperature == 0 ? "AUTO" : engine.wbTemperature + "K"));
        evChip.setText("EXPOSURE\n" + (engine.exposure > 0 ? "+" : "") + engine.exposure);
        processingChip.setText("NR/EDGE\n" + (engine.naturalProcessing ? "OFF*" : "AUTO"));
    }
    private void chooseIso() {
        String[] opts = {"Auto", "100", "200", "400", "800", "1600", "3200", "6400"};
        choose("Sensor ISO (manual)", opts, i -> { engine.iso = i == 0 ? 0 : Integer.parseInt(opts[i]); updateSettings(); });
    }
    private void chooseShutter() {
        String[] opts = {"Auto", "1/1000", "1/500", "1/250", "1/125", "1/60", "1/30", "1/15", "1/8", "1/4"};
        choose("Shutter speed", opts, i -> {
            engine.shutterNs = i == 0 ? 0 : 1_000_000_000L / Integer.parseInt(opts[i].substring(2));
            updateSettings();
        });
    }
    private void chooseFocus() {
        String[] opts = {"Auto", "Infinity", "0.5 diopters", "1 diopter", "2 diopters", "4 diopters"};
        float[] distances = {-1f, 0f, .5f, 1f, 2f, 4f};
        choose("Manual focus", opts, i -> { engine.focusDistance = distances[i]; updateSettings(); });
    }
    private void chooseWb() {
        String[] opts = {"Auto", "2800K Tungsten", "3200K Warm", "4500K Fluorescent", "5600K Daylight", "6500K Cloudy", "8000K Shade"};
        int[] values = {0, 2800, 3200, 4500, 5600, 6500, 8000};
        choose("White balance (approximate)", opts, i -> { engine.wbTemperature = values[i]; updateSettings(); });
    }
    private void chooseEv() {
        String[] opts = {"-3 steps", "-2 steps", "-1 step", "0", "+1 step", "+2 steps", "+3 steps"};
        choose("Exposure compensation", opts, i -> { engine.exposure = i - 3; updateSettings(); });
    }
    private interface Pick { void picked(int i); }
    private void choose(String title, String[] options, Pick pick) {
        if (engine == null || recording) return;
        new AlertDialog.Builder(this).setTitle(title).setItems(options, (d, which) -> pick.picked(which))
                .setNegativeButton("Cancel", null).show();
    }
    private void updateSettings() { if (engine != null) engine.refreshControls(); updateControlLabels(); }

    private void showSettings() {
        if (engine == null) { toast("Camera starting"); return; }
        if (recording || engine.isRecording()) { toast("Stop recording to change settings"); return; }
        String[] opts = {
                "Video resolution   ·   " + engine.width + "×" + engine.height,
                "Frame rate   ·   " + engine.frameRate + " fps",
                "Video bitrate   ·   " + (engine.bitrate / 1_000_000) + " Mbps",
                "Video codec   ·   " + (engine.hevc ? "H.265 / HEVC" : "H.264 / AVC"),
                "Stabilization   ·   " + (engine.stabilize ? "On" : "Off"),
                "Microphone   ·   " + (engine.includeAudio ? "On" : "Off"),
                "Audio channels   ·   " + (engine.audioChannels == 2 ? "Stereo" : "Mono"),
                "Audio source   ·   " + new String[]{"System default", "Built-in", "USB", "Bluetooth"}[engine.preferredAudioType],
                "Photo size   ·   " + (engine.maximumPhotoResolution ? "Maximum" : "Up to 13 MP"),
                "3×3 grid   ·   " + (showGrid ? "On" : "Off"),
                "Reduced NR/Sharpening   ·   " + (engine.naturalProcessing ? "Requested" : "Off"),
                "Default camera settings  ↗"
        };
        new AlertDialog.Builder(this).setTitle("Sushi Camera / Settings")
                .setItems(opts, (d, which) -> {
                    switch (which) {
                        case 0: choose("Video resolution", new String[]{"1280×720", "1920×1080", "3840×2160"}, i -> {
                            engine.width = new int[]{1280,1920,3840}[i];
                            engine.height = new int[]{720,1080,2160}[i]; showSettings();
                        }); break;
                        case 1: choose("Video frame rate", new String[]{"24 fps", "30 fps", "60 fps"}, i -> {
                            engine.frameRate = new int[]{24,30,60}[i]; engine.refreshControls(); showSettings();
                        }); break;
                        case 2: choose("Video bitrate", new String[]{"8 Mbps", "16 Mbps", "32 Mbps", "50 Mbps", "80 Mbps"}, i -> {
                            engine.bitrate = new int[]{8,16,32,50,80}[i] * 1_000_000; showSettings();
                        }); break;
                        case 3: engine.hevc = !engine.hevc; showSettings(); break;
                        case 4: engine.stabilize = !engine.stabilize; updateSettings(); showSettings(); break;
                        case 5: engine.includeAudio = !engine.includeAudio; showSettings(); break;
                        case 6: engine.audioChannels = engine.audioChannels == 2 ? 1 : 2; showSettings(); break;
                        case 7: choose("Preferred microphone", new String[]{"System default", "Built-in", "USB", "Bluetooth"},
                                i -> { engine.preferredAudioType = i; showSettings(); }); break;
                        case 8: engine.maximumPhotoResolution = !engine.maximumPhotoResolution;
                            toast("Photo resolution applies after switching lenses or reopening camera"); showSettings(); break;
                        case 9: showGrid = !showGrid; grid.setVisibility(showGrid ? View.VISIBLE : View.GONE); showSettings(); break;
                        case 10: engine.naturalProcessing = !engine.naturalProcessing; updateSettings(); showSettings(); break;
                        case 11: openDefaultSettings(); break;
                    }
                }).setPositiveButton("Done", null).show();
    }

    private void openDefaultSettings() {
        new AlertDialog.Builder(this).setTitle("About the default camera")
                .setMessage("Sushi Camera advertises still/video camera intents. However, Android 11+ generally reserves implicit photo/video capture handling for preinstalled system cameras. HyperOS may also lock the power-button and lock-screen camera shortcuts to its stock camera. If your device offers a camera-default option, try it here; the app cannot force this system setting.")
                .setPositiveButton("Open Android settings", (d, w) -> {
                    try { startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)); }
                    catch (ActivityNotFoundException ex) {
                        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + getPackageName())));
                    }
                }).setNegativeButton("Close", null).show();
    }

    private void showLensDialog() {
        if (engine == null) return;
        List<CameraEngine.Lens> ls = engine.getLenses();
        if (ls.isEmpty()) { toast("Android is still discovering lenses"); return; }
        String[] names = new String[ls.size()];
        for (int i=0; i<ls.size(); i++) names[i] = ls.get(i).toString();
        new AlertDialog.Builder(this).setTitle("Select camera lens")
                .setItems(names, (d, i) -> engine.selectLens(ls.get(i).id))
                .setNegativeButton("Cancel", null).show();
    }

    private void showLastCapture() {
        if (lastCapture == null) { toast("Take a photo or video first"); return; }
        Intent in = new Intent(Intent.ACTION_VIEW);
        in.setDataAndType(lastCapture, lastCaptureIsVideo == 1 ? "video/mp4" : "image/jpeg");
        in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(in); }
        catch (ActivityNotFoundException ex) { toast("No viewer installed"); }
    }

    @Override public boolean onKeyDown(int key, KeyEvent event) {
        if (key == KeyEvent.KEYCODE_VOLUME_DOWN || key == KeyEvent.KEYCODE_VOLUME_UP || key == KeyEvent.KEYCODE_CAMERA) {
            if (event.getRepeatCount() == 0) capture();
            return true;
        }
        return super.onKeyDown(key, event);
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
    @Override public void status(String text) { if (status != null && !recording) status.setText(text); }
    @Override public void error(String text) { if (status != null) status.setText("ERROR  ·  " + text); toast(text); }
    @Override public void selectedLens(String lens) { lensLabel.setText(lens); updateControlLabels(); updateZoomLabel(); }
    @Override public void recording(boolean active) {
        recording = active;
        mainHandler.removeCallbacks(updateTimer);
        if (active) {
            recordStartMs = android.os.SystemClock.elapsedRealtime();
            mainHandler.post(updateTimer);
        } else status.setText(isVideo ? "VIDEO  ·  READY" : "PHOTO  ·  READY");
        updateModeButtons();
    }
    @Override public void saved(Uri uri, boolean video, boolean external, Bitmap thumb) {
        if (uri == null) return;
        lastCapture = uri; lastCaptureIsVideo = video ? 1 : 0;
        if (thumb != null) galleryImage.setImageBitmap(thumb);
        else if (video) galleryText.setText("VIDEO ✓");
        if (external && ((video && MediaStore.ACTION_VIDEO_CAPTURE.equals(getIntent().getAction())) ||
                (!video && MediaStore.ACTION_IMAGE_CAPTURE.equals(getIntent().getAction())))) {
            Intent result = new Intent(); result.setData(uri);
            result.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (!video && thumb != null) result.putExtra("data", thumb);
            setResult(RESULT_OK, result); finish(); return;
        }
        if ((video && MediaStore.ACTION_VIDEO_CAPTURE.equals(getIntent().getAction())) ||
                (!video && MediaStore.ACTION_IMAGE_CAPTURE.equals(getIntent().getAction()))) {
            Intent result = new Intent(); result.setData(uri);
            result.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (!video && thumb != null) result.putExtra("data", thumb);
            setResult(RESULT_OK, result); finish(); return;
        }
        toast(video ? "Video saved to DCIM/SushiCamera" : "Photo saved to DCIM/SushiCamera");
    }

    private final class GridLines extends View {
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        GridLines() { super(MainActivity.this); setClickable(false); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); paint.setColor(0x88FFFFFF); paint.setStrokeWidth(dp(.7f));
            float w = getWidth(), h = getHeight();
            for (int i=1; i<3; i++) {
                c.drawLine(w*i/3f, 0, w*i/3f, h, paint);
                c.drawLine(0, h*i/3f, w, h*i/3f, paint);
            }
        }
    }
}
