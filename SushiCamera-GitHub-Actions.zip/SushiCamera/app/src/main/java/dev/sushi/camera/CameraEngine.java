package dev.sushi.camera;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.RggbChannelVector;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.Range;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Android framework-only Camera2 implementation, no advertising/analytics/network dependencies. */
@SuppressWarnings("deprecation")
public final class CameraEngine {
    public interface Callbacks {
        void status(String status);
        void error(String error);
        void saved(Uri uri, boolean video, boolean external, Bitmap thumb);
        void recording(boolean active);
        void selectedLens(String description);
    }

    public static final class Lens {
        public final String id;
        public final int facing;
        public final String name;
        Lens(String id, int facing, String name) {
            this.id = id; this.facing = facing; this.name = name;
        }
        @Override public String toString() { return name + "  ·  ID " + id; }
    }

    public volatile int iso = 0;               // 0 = Auto
    public volatile long shutterNs = 0;        // 0 = Auto
    public volatile float focusDistance = -1;  // -1 = Auto, diopters otherwise
    public volatile int wbTemperature = 0;     // 0 = Auto, else approximate Kelvin
    public volatile int exposure = 0;          // integer compensation steps
    public volatile float zoom = 1f;
    public volatile boolean stabilize = true;
    public volatile boolean torch = false;
    public volatile boolean naturalProcessing = false;
    public volatile boolean includeAudio = true;
    public volatile int audioChannels = 2;
    public volatile int preferredAudioType = 0; // 0 default, 1 built-in, 2 USB, 3 BT
    public volatile int frameRate = 30;
    public volatile int width = 1920;
    public volatile int height = 1080;
    public volatile int bitrate = 16000000;
    public volatile boolean hevc = false;
    public volatile boolean maximumPhotoResolution = false;

    private final Context context;
    private final TextureView preview;
    private final Callbacks callbacks;
    private final CameraManager manager;
    private final List<Lens> lenses = new ArrayList<>();
    private HandlerThread thread;
    private Handler handler;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private ImageReader photoReader;
    private MediaRecorder recorder;
    private ParcelFileDescriptor mediaDescriptor;
    private Surface previewSurface;
    private Uri pendingUri;
    private boolean pendingOwned;
    private boolean started;
    private boolean opening;
    private boolean closing;
    private boolean recording;
    private boolean preparingRecording;
    private boolean videoMode;
    private String cameraId;
    private String nextCameraId;
    private Size previewSize = new Size(1280, 720);
    private CameraCharacteristics characteristics;
    private CaptureRequest.Builder previewRequest;
    private long recordingStart;

    public CameraEngine(Context context, TextureView preview, Callbacks callbacks) {
        this.context = context;
        this.preview = preview;
        this.callbacks = callbacks;
        this.manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
    }

    public List<Lens> getLenses() { synchronized (lenses) { return new ArrayList<>(lenses); } }

    public void start() {
        if (thread != null) return;
        thread = new HandlerThread("SushiCamera2");
        thread.start();
        handler = new Handler(thread.getLooper());
        started = true;
        run(this::discoverAndOpen);
    }

    public void stop() {
        started = false;
        if (handler != null) {
            Handler h = handler;
            h.post(() -> {
                if (recording) stopRecordingInternal(false);
                else if (preparingRecording) abandonRecording();
                closeResources();
            });
            thread.quitSafely();
        }
        handler = null;
        thread = null;
    }

    private void run(Runnable work) { Handler h = handler; if (h != null) h.post(work); }
    private void info(String message) { context.getMainExecutor().execute(() -> callbacks.status(message)); }
    private void fail(String message, Exception e) {
        android.util.Log.e("SushiCamera", message, e);
        context.getMainExecutor().execute(() -> callbacks.error(message + (e == null ? "" : ": " + e.getMessage())));
    }

    private void discoverAndOpen() {
        try {
            List<Lens> found = new ArrayList<>();
            for (String id : manager.getCameraIdList()) {
                CameraCharacteristics c = manager.getCameraCharacteristics(id);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                int f = facing == null ? CameraCharacteristics.LENS_FACING_BACK : facing;
                float[] focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
                String fl = focal == null || focal.length == 0 ? "" : String.format(Locale.US, "%.1fmm", focal[0]);
                String facingName = f == CameraCharacteristics.LENS_FACING_FRONT ? "SELFIE" :
                        f == CameraCharacteristics.LENS_FACING_BACK ? "REAR" : "EXTERNAL";
                found.add(new Lens(id, f, facingName + (fl.isEmpty() ? "" : " " + fl)));
            }
            found.sort(Comparator.comparingInt((Lens l) -> l.facing == CameraCharacteristics.LENS_FACING_BACK ? 0 : 1));
            synchronized (lenses) { lenses.clear(); lenses.addAll(found); }
            if (found.isEmpty()) { fail("No accessible cameras", null); return; }
            if (cameraId == null) cameraId = found.get(0).id;
            requestOpen();
        } catch (CameraAccessException | SecurityException ex) { fail("Cannot enumerate lenses", ex); }
    }

    public void selectLens(String id) {
        run(() -> {
            if (id == null || id.equals(cameraId)) return;
            if (recording || preparingRecording) { info("Stop video before changing lenses"); return; }
            nextCameraId = id;
            if (camera != null) closeResources();
            else if (!closing) { cameraId = id; nextCameraId = null; requestOpen(); }
        });
    }

    public void toggleFrontRear() {
        List<Lens> ls = getLenses();
        Lens current = null;
        for (Lens l : ls) if (l.id.equals(cameraId)) current = l;
        if (current == null) return;
        int needed = current.facing == CameraCharacteristics.LENS_FACING_FRONT ?
                CameraCharacteristics.LENS_FACING_BACK : CameraCharacteristics.LENS_FACING_FRONT;
        for (Lens l : ls) if (l.facing == needed) { selectLens(l.id); return; }
        info("No opposite-facing camera is exposed by Android");
    }

    @SuppressLint("MissingPermission")
    private void requestOpen() {
        if (!started || camera != null || opening || closing || !preview.isAvailable()) return;
        if (context.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        try {
            characteristics = manager.getCameraCharacteristics(cameraId);
            StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map == null) throw new IllegalStateException("Camera stream configuration unavailable");
            Size[] sizes = map.getOutputSizes(SurfaceTexture.class);
            previewSize = choosePreview(sizes);
            opening = true;
            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice device) {
                    opening = false;
                    if (!started) { device.close(); return; }
                    camera = device;
                    Lens match = null;
                    for (Lens l : getLenses()) if (l.id.equals(cameraId)) match = l;
                    String label = match == null ? "CAM " + cameraId : match.name;
                    context.getMainExecutor().execute(() -> callbacks.selectedLens(label));
                    createPhotoSession();
                }
                @Override public void onDisconnected(CameraDevice device) {
                    device.close(); if (camera == device) camera = null;
                    opening = false; fail("Camera disconnected", null);
                }
                @Override public void onError(CameraDevice device, int error) {
                    device.close(); if (camera == device) camera = null;
                    opening = false; fail("Camera error " + error, null);
                }
                @Override public void onClosed(CameraDevice device) {
                    closing = false;
                    if (started && nextCameraId != null) {
                        cameraId = nextCameraId; nextCameraId = null; requestOpen();
                    }
                }
            }, handler);
        } catch (Exception e) { opening = false; fail("Failed to open camera", e); }
    }

    private Size choosePreview(Size[] sizes) {
        if (sizes == null || sizes.length == 0) return new Size(1280, 720);
        Size best = sizes[0];
        double bestScore = Double.MAX_VALUE;
        for (Size size : sizes) {
            double ratio = size.getWidth() / (double) size.getHeight();
            double score = Math.abs(ratio - 16.0 / 9.0) * 5000 +
                    Math.abs(size.getWidth() - 1920) / 2.0 +
                    Math.abs(size.getHeight() - 1080) / 2.0;
            if (size.getWidth() > 1920 || size.getHeight() > 1080) score += 1500;
            if (score < bestScore) { bestScore = score; best = size; }
        }
        return best;
    }

    private Size photoSize() {
        StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        Size[] sizes = map == null ? null : map.getOutputSizes(ImageFormat.JPEG);
        if (sizes == null || sizes.length == 0) return new Size(1920, 1080);
        Arrays.sort(sizes, (a, b) -> Long.compare((long) b.getWidth() * b.getHeight(),
                (long) a.getWidth() * a.getHeight()));
        if (maximumPhotoResolution) return sizes[0];
        for (Size size : sizes) if ((long) size.getWidth() * size.getHeight() <= 13_000_000L) return size;
        return sizes[sizes.length - 1];
    }

    private Surface currentPreviewSurface() {
        SurfaceTexture texture = preview.getSurfaceTexture();
        if (texture == null) throw new IllegalStateException("Preview surface not ready");
        texture.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
        context.getMainExecutor().execute(this::transformPreview);
        if (previewSurface != null) previewSurface.release();
        previewSurface = new Surface(texture);
        return previewSurface;
    }

    private void transformPreview() {
        if (!preview.isAvailable()) return;
        int vw = preview.getWidth(), vh = preview.getHeight();
        if (vw == 0 || vh == 0) return;
        // Portrait-only UI; Camera2 TextureView crop-to-fill with sensor aspect ratio.
        float bufferWidth = previewSize.getHeight(), bufferHeight = previewSize.getWidth();
        float scale = Math.max(vw / bufferWidth, vh / bufferHeight);
        Matrix matrix = new Matrix();
        RectF from = new RectF(0, 0, vw, vh);
        RectF to = new RectF(0, 0, bufferWidth * scale, bufferHeight * scale);
        to.offset((vw - to.width()) / 2f, (vh - to.height()) / 2f);
        matrix.setRectToRect(from, to, Matrix.ScaleToFit.FILL);
        preview.setTransform(matrix);
    }

    private void closeSession() {
        if (session != null) { try { session.close(); } catch (Exception ignored) {} session = null; }
        previewRequest = null;
    }

    private void closeResources() {
        closeSession();
        if (photoReader != null) { photoReader.close(); photoReader = null; }
        if (previewSurface != null) { previewSurface.release(); previewSurface = null; }
        if (camera != null) {
            closing = true;
            CameraDevice device = camera; camera = null;
            device.close();
        }
    }

    private void createPhotoSession() {
        if (camera == null || !preview.isAvailable()) return;
        try {
            closeSession();
            if (photoReader != null) { photoReader.close(); photoReader = null; }
            Size p = photoSize();
            photoReader = ImageReader.newInstance(p.getWidth(), p.getHeight(), ImageFormat.JPEG, 2);
            photoReader.setOnImageAvailableListener(this::savePhoto, handler);
            Surface surface = currentPreviewSurface();
            ImageReader reader = photoReader;
            camera.createCaptureSession(Arrays.asList(surface, reader.getSurface()), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession s) {
                    if (camera == null || photoReader != reader) { s.close(); return; }
                    session = s;
                    try {
                        previewRequest = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                        previewRequest.addTarget(surface);
                        applyControls(previewRequest, false);
                        session.setRepeatingRequest(previewRequest.build(), null, handler);
                        info("READY  ·  " + p.getWidth() + " × " + p.getHeight());
                    } catch (Exception ex) { fail("Cannot start preview", ex); }
                }
                @Override public void onConfigureFailed(CameraCaptureSession s) { fail("Camera preview not supported", null); }
            }, handler);
        } catch (Exception e) { fail("Preview initialization failed", e); }
    }

    public void refreshControls() {
        run(() -> {
            if (session != null && previewRequest != null) try {
                applyControls(previewRequest, recording);
                session.setRepeatingRequest(previewRequest.build(), null, handler);
            } catch (Exception ex) { fail("Camera rejected control", ex); }
        });
    }

    private <T> void supportedSet(CaptureRequest.Builder b, CaptureRequest.Key<T> key, T value) {
        if (characteristics != null && characteristics.getAvailableCaptureRequestKeys().contains(key)) {
            try { b.set(key, value); } catch (IllegalArgumentException ignored) { }
        }
    }

    private boolean hasManualSensor() {
        int[] caps = characteristics == null ? null : characteristics.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
        if (caps != null) for (int cap : caps) if (cap == CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) return true;
        return false;
    }

    private void applyControls(CaptureRequest.Builder b, boolean video) {
        if (characteristics == null) return;
        supportedSet(b, CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
        boolean manual = (iso > 0 || shutterNs > 0) && hasManualSensor();
        if (manual) {
            Range<Integer> isoRange = characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
            Range<Long> timeRange = characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
            int actualIso = iso > 0 ? iso : 200;
            long actualTime = shutterNs > 0 ? shutterNs : 16_666_667L;
            if (isoRange != null) actualIso = Math.max(isoRange.getLower(), Math.min(isoRange.getUpper(), actualIso));
            if (timeRange != null) actualTime = Math.max(timeRange.getLower(), Math.min(timeRange.getUpper(), actualTime));
            supportedSet(b, CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF);
            supportedSet(b, CaptureRequest.SENSOR_SENSITIVITY, actualIso);
            supportedSet(b, CaptureRequest.SENSOR_EXPOSURE_TIME, actualTime);
            supportedSet(b, CaptureRequest.SENSOR_FRAME_DURATION, Math.max(actualTime, 1_000_000_000L / Math.max(1, frameRate)));
        } else {
            supportedSet(b, CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            Range<Integer> evRange = characteristics.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            int ev = exposure;
            if (evRange != null) ev = Math.max(evRange.getLower(), Math.min(evRange.getUpper(), ev));
            supportedSet(b, CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, ev);
        }
        Float minFocus = characteristics.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE);
        if (focusDistance >= 0 && minFocus != null && minFocus > 0) {
            supportedSet(b, CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF);
            supportedSet(b, CaptureRequest.LENS_FOCUS_DISTANCE, Math.min(minFocus, focusDistance));
        } else {
            supportedSet(b, CaptureRequest.CONTROL_AF_MODE, video ?
                    CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO : CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
        }
        if (wbTemperature > 0) {
            supportedSet(b, CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_OFF);
            float warmer = Math.max(.6f, Math.min(2.2f, 5600f / wbTemperature));
            supportedSet(b, CaptureRequest.COLOR_CORRECTION_GAINS,
                    new RggbChannelVector(1.7f * warmer, 1.0f, 1.0f, 1.7f / warmer));
        } else supportedSet(b, CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO);
        Rect sensorRect = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
        Float maxZoom = characteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
        if (sensorRect != null) {
            float z = Math.max(1f, Math.min(maxZoom == null ? 1f : maxZoom, zoom));
            int cw = Math.round(sensorRect.width() / z), ch = Math.round(sensorRect.height() / z);
            int left = sensorRect.left + (sensorRect.width() - cw) / 2;
            int top = sensorRect.top + (sensorRect.height() - ch) / 2;
            supportedSet(b, CaptureRequest.SCALER_CROP_REGION, new Rect(left, top, left + cw, top + ch));
        }
        Range<Integer>[] ranges = characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
        if (ranges != null && ranges.length > 0) {
            Range<Integer> match = ranges[0]; int penalty = Integer.MAX_VALUE;
            for (Range<Integer> range : ranges) {
                int p = Math.abs(range.getUpper() - frameRate) * 100 + Math.abs(range.getLower() - frameRate);
                if (p < penalty) { penalty = p; match = range; }
            }
            supportedSet(b, CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, match);
        }
        if (video && stabilize) {
            supportedSet(b, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON);
            supportedSet(b, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF);
        } else {
            supportedSet(b, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF);
            supportedSet(b, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, stabilize ?
                    CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON : CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF);
        }
        if (naturalProcessing) {
            supportedSet(b, CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_OFF);
            supportedSet(b, CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_OFF);
        }
        Boolean flashAvailable = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
        supportedSet(b, CaptureRequest.FLASH_MODE, torch && Boolean.TRUE.equals(flashAvailable) ?
                CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
    }

    public void focusOnce() {
        run(() -> {
            if (session == null || previewRequest == null || focusDistance >= 0) return;
            try {
                previewRequest.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START);
                session.capture(previewRequest.build(), null, handler);
                previewRequest.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_IDLE);
                session.setRepeatingRequest(previewRequest.build(), null, handler);
            } catch (Exception e) { fail("Focus failed", e); }
        });
    }

    public void takePhoto(Uri externalOutput) {
        run(() -> {
            if (camera == null || session == null || photoReader == null || recording || preparingRecording) {
                info("Camera not ready"); return;
            }
            try {
                photoDestination = externalOutput;
                CaptureRequest.Builder photo = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                photo.addTarget(photoReader.getSurface());
                applyControls(photo, false);
                Integer orientation = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
                int facing = characteristics.get(CameraCharacteristics.LENS_FACING) == null ? 1 :
                        characteristics.get(CameraCharacteristics.LENS_FACING);
                int deg = orientation == null ? 90 : orientation;
                photo.set(CaptureRequest.JPEG_ORIENTATION, facing == CameraCharacteristics.LENS_FACING_FRONT ? (360 - deg) % 360 : deg);
                photo.set(CaptureRequest.JPEG_QUALITY, (byte) 95);
                session.capture(photo.build(), null, handler);
            } catch (Exception e) { photoDestination = null; fail("Photo capture failed", e); }
        });
    }

    private Uri photoDestination;
    private void savePhoto(ImageReader reader) {
        Image image = null;
        Uri uri = null;
        boolean owned = false;
        try {
            image = reader.acquireNextImage();
            if (image == null) return;
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.remaining()];
            buffer.get(bytes);
            Uri external = photoDestination;
            photoDestination = null;
            if (external != null) uri = external;
            else {
                uri = makeMediaItem(false);
                owned = true;
            }
            try (OutputStream out = context.getContentResolver().openOutputStream(uri, "w")) {
                if (out == null) throw new IOException("Cannot open photo destination");
                out.write(bytes);
            }
            if (owned) completeMediaItem(uri);
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 16;
            Bitmap thumb = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
            final Uri done = uri;
            final boolean isExternal = !owned;
            context.getMainExecutor().execute(() -> callbacks.saved(done, false, isExternal, thumb));
        } catch (Exception ex) {
            if (uri != null && owned) context.getContentResolver().delete(uri, null, null);
            fail("Could not save photo", ex);
        } finally { if (image != null) image.close(); }
    }

    private Uri makeMediaItem(boolean video) throws IOException {
        ContentValues values = new ContentValues();
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, "SUSHI_" + timestamp + (video ? ".mp4" : ".jpg"));
        values.put(MediaStore.MediaColumns.MIME_TYPE, video ? "video/mp4" : "image/jpeg");
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/SushiCamera");
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri base = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        Uri result = context.getContentResolver().insert(base, values);
        if (result == null) throw new IOException("MediaStore insert returned null");
        return result;
    }

    private void completeMediaItem(Uri uri) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.IS_PENDING, 0);
        context.getContentResolver().update(uri, values, null, null);
    }

    public void startVideo(Uri externalOutput) {
        run(() -> {
            if (camera == null || session == null || recording || preparingRecording) { info("Camera not ready"); return; }
            try {
                preparingRecording = true;
                pendingUri = externalOutput == null ? makeMediaItem(true) : externalOutput;
                pendingOwned = externalOutput == null;
                mediaDescriptor = context.getContentResolver().openFileDescriptor(pendingUri, "w");
                if (mediaDescriptor == null) throw new IOException("Cannot open video destination");
                Size videoSize = selectVideoSize();
                recorder = new MediaRecorder();
                boolean withMic = includeAudio && context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
                if (withMic) recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
                recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                recorder.setVideoEncoder(hevc ? MediaRecorder.VideoEncoder.HEVC : MediaRecorder.VideoEncoder.H264);
                recorder.setVideoEncodingBitRate(bitrate);
                recorder.setVideoFrameRate(frameRate);
                recorder.setVideoSize(videoSize.getWidth(), videoSize.getHeight());
                if (withMic) {
                    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                    recorder.setAudioChannels(audioChannels);
                    recorder.setAudioSamplingRate(48000);
                    recorder.setAudioEncodingBitRate(audioChannels == 2 ? 192000 : 96000);
                    AudioDeviceInfo preferred = findPreferredMic();
                    if (preferred != null) recorder.setPreferredDevice(preferred);
                }
                Integer sensor = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
                Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
                int degrees = sensor == null ? 90 : sensor;
                recorder.setOrientationHint(facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT ? (360 - degrees) % 360 : degrees);
                recorder.setOutputFile(mediaDescriptor.getFileDescriptor());
                recorder.prepare();
                closeSession();
                if (photoReader != null) { photoReader.close(); photoReader = null; }
                Surface cameraPreview = currentPreviewSurface();
                Surface videoSurface = recorder.getSurface();
                camera.createCaptureSession(Arrays.asList(cameraPreview, videoSurface), new CameraCaptureSession.StateCallback() {
                    @Override public void onConfigured(CameraCaptureSession s) {
                        if (!preparingRecording || camera == null || recorder == null) { s.close(); return; }
                        session = s;
                        try {
                            previewRequest = camera.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
                            previewRequest.addTarget(cameraPreview);
                            previewRequest.addTarget(videoSurface);
                            applyControls(previewRequest, true);
                            session.setRepeatingRequest(previewRequest.build(), null, handler);
                            recorder.start();
                            recordingStart = android.os.SystemClock.elapsedRealtime();
                            recording = true; preparingRecording = false;
                            String resolution = videoSize.getWidth() + "×" + videoSize.getHeight();
                            info("REC  " + resolution + "  " + frameRate + "fps");
                            context.getMainExecutor().execute(() -> callbacks.recording(true));
                        } catch (Exception ex) { fail("Video start failed", ex); abandonRecording(); createPhotoSession(); }
                    }
                    @Override public void onConfigureFailed(CameraCaptureSession s) {
                        fail("Video configuration unsupported on this lens", null);
                        abandonRecording(); createPhotoSession();
                    }
                }, handler);
            } catch (Exception ex) { fail("Recording setup failed", ex); abandonRecording(); createPhotoSession(); }
        });
    }

    private Size selectVideoSize() {
        StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        Size[] sizes = map == null ? null : map.getOutputSizes(MediaRecorder.class);
        if (sizes == null || sizes.length == 0) return new Size(1280, 720);
        Size fallback = null;
        for (Size s : sizes) {
            if (s.getWidth() == width && s.getHeight() == height) return s;
            if (s.getWidth() == 1920 && s.getHeight() == 1080) fallback = s;
        }
        if (fallback != null) { info("Requested resolution unavailable; using 1080p"); return fallback; }
        return sizes[0];
    }

    private AudioDeviceInfo findPreferredMic() {
        if (preferredAudioType == 0) return null;
        AudioManager audio = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        for (AudioDeviceInfo device : audio.getDevices(AudioManager.GET_DEVICES_INPUTS)) {
            int type = device.getType();
            boolean builtIn = type == AudioDeviceInfo.TYPE_BUILTIN_MIC;
            boolean usb = type == AudioDeviceInfo.TYPE_USB_DEVICE || type == AudioDeviceInfo.TYPE_USB_HEADSET;
            boolean bt = type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || type == AudioDeviceInfo.TYPE_BLE_HEADSET;
            if ((preferredAudioType == 1 && builtIn) || (preferredAudioType == 2 && usb) ||
                    (preferredAudioType == 3 && bt)) return device;
        }
        info("Selected microphone not connected, using system default");
        return null;
    }

    public void stopVideo() { run(() -> stopRecordingInternal(true)); }

    private void stopRecordingInternal(boolean restartPreview) {
        if (!recording) return;
        boolean good = true;
        closeSession();
        try { recorder.stop(); }
        catch (RuntimeException ex) { good = false; fail("Short/invalid video removed", ex); }
        try { recorder.reset(); recorder.release(); } catch (Exception ignored) { }
        recorder = null;
        try { if (mediaDescriptor != null) mediaDescriptor.close(); } catch (Exception ignored) { }
        mediaDescriptor = null;
        Uri completedUri = pendingUri;
        boolean owned = pendingOwned;
        pendingUri = null; pendingOwned = false;
        recording = false;
        context.getMainExecutor().execute(() -> callbacks.recording(false));
        if (completedUri != null) {
            if (!good && owned) context.getContentResolver().delete(completedUri, null, null);
            else if (good) {
                if (owned) completeMediaItem(completedUri);
                Uri finalUri = completedUri;
                context.getMainExecutor().execute(() -> callbacks.saved(finalUri, true, !owned, null));
            }
        }
        if (restartPreview && started) createPhotoSession();
    }

    private void abandonRecording() {
        preparingRecording = false; recording = false;
        closeSession();
        try { if (recorder != null) { recorder.reset(); recorder.release(); } } catch (Exception ignored) {}
        recorder = null;
        try { if (mediaDescriptor != null) mediaDescriptor.close(); } catch (Exception ignored) {}
        mediaDescriptor = null;
        if (pendingOwned && pendingUri != null) context.getContentResolver().delete(pendingUri, null, null);
        pendingUri = null; pendingOwned = false;
        context.getMainExecutor().execute(() -> callbacks.recording(false));
    }

    public boolean isRecording() { return recording || preparingRecording; }
    public float getMaxZoom() {
        try {
            if (characteristics == null) return 6f;
            Float z = characteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
            return z == null ? 6f : Math.max(1f, Math.min(20f, z));
        } catch (Exception e) { return 6f; }
    }
}
