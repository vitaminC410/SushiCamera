# Sushi Camera — Camera2 Pro Camera for Android

An independent, open-source-inspired **first implementation**, modeled on the *feature categories* of N8 Media's Native Camera, not a copy of its proprietary app, logo, source, or assets. All code in this project was written for this project.

## What is implemented

- Android Camera2 live preview, selectable exposed back/front/auxiliary camera IDs, pinch zoom and zoom slider.
- JPEG still photos with auto/manual focus options, shutter time, sensor ISO (only when Camera2 reports manual-sensor support), AWB/approximate Kelvin color gains, exposure compensation, torch, lower noise reduction/edge sharpening requests, and high-resolution JPEG option.
- H.264 or H.265 **8-bit SDR** MP4 recording through MediaRecorder; configurable 720p, 1080p, 4K **when the particular camera exposes that video size**, 24/30/60 fps **when hardware supports them**, 8–80 Mbps requested bitrate, and video stabilization.
- Microphone recording on/off, mono/stereo, requested internal/USB/Bluetooth input routing (audio routing may be overridden by Android).
- Auto-local save in `DCIM/SushiCamera` with MediaStore and scoped storage. No advertising SDK, tracking, accounts, or internet permission.
- Save to the requesting app's supplied `MediaStore.EXTRA_OUTPUT` URI for third-party photo/video capture intents; finish and return its URI when done.
- Manifest declares `STILL_IMAGE_CAMERA`, `VIDEO_CAMERA`, `IMAGE_CAPTURE` and `VIDEO_CAPTURE` as activity intents (also supports direct launching from the launcher).
- In-app access to Android's Default apps page and an explanation of the restrictions.
- Full-screen dark UI, controls, 3x3 grid, volume-button capture, last-capture viewer, persistent preferences.

## Limitations — IMPORTANT

This is a **source-code prototype, not a verified release APK**. It has not been compiled or run on a physical handset within this environment. Camera hardware is highly device-specific. Test on-device before relying on it.

- **It cannot forcibly become the system-default camera.** Beginning with Android 11, ordinary installed third-party apps are not automatically eligible for implicit `ACTION_IMAGE_CAPTURE` / `ACTION_VIDEO_CAPTURE` intent dispatch as system default. An app may be launched explicitly for capture. Xiaomi HyperOS power-button and lock-screen camera shortcuts can be manufacturer-restricted, too. Intent filters enable compatible selection when the OS permits it, but **do not bypass that restriction**.
- A third-party app cannot always access ultra-wide, macro, optical zoom or vendor-specific sensor modes: it will list only camera IDs exposed to Camera2. No guarantee of capturing the same image quality as Xiaomi's OEM pipeline.
- **NOT implemented:** true 10-bit HLG/HDR, RAW DNG, histogram, zebra stripes, face auto-exposure, proprietary manufacturer video processing bypass, lossless files, advanced microphone gain, full per-lens physical camera routing, or higher-than-normal speed recording.
- Manual WB color-gain controls are approximate, and can be ignored by some camera HALs. ISO and shutter are only applied when `MANUAL_SENSOR` capability exists. Some camera drivers can refuse high fps, 4K, or high bitrate requests despite size enumeration; errors are shown rather than silently producing claimed resolutions.
- Photo/video UI is locked to portrait in this version. Some HALs may require a preview transform adjustment; validate orientation of output files.
- For security and simplicity, `IMAGE_CAPTURE_SECURE` is not declared and lock-screen secure capture is not implemented.

## Build a downloadable APK with GitHub Actions (no local Android SDK)

This ZIP includes `.github/workflows/build-apk.yml`. The workflow runs on **push to `main` / `master`** and can also be started manually using `workflow_dispatch`. It downloads Android SDK 35, sets up Java 17 and Gradle 8.9, compiles the **unsigned-for-release, automatically debug-signed** APK, verifies its presence, and uploads `app-debug.apk` as a GitHub Actions artifact. No GitHub tokens or app signing keys need to be added for debug builds. **A debug build is for personal testing, not Play Store publishing.**

1. Create a GitHub repository (e.g. `SushiCamera`).
2. Upload or push the **contents of this `SushiCamera` directory** to the repository's root. You must include the hidden `.github/workflows/build-apk.yml` file, and `app`, `build.gradle`, and `settings.gradle` must be at the repository root, NOT under a second nested `SushiCamera` directory. GitHub does not extract ZIP files uploaded as individual files.
3. On GitHub, open **Actions → Build Sushi Camera APK → Run workflow → Run workflow**, or push a commit to `main`.
4. Once the run has a green check, open its details and select **Artifacts → SushiCamera-debug-APK**. GitHub downloads an artifact ZIP; extract it to get `app-debug.apk`.
5. Copy the APK to your phone, open it and allow installation from that source if Android asks. Grant camera permission (microphone is optional).

When using git from a terminal within the extracted inner `SushiCamera/` directory:

```sh
git init
git add .
git commit -m "Add Sushi Camera and GitHub Actions APK build"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/SushiCamera.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub name and create the remote repository first. GitHub requires authentication (e.g. via Git Credential Manager or SSH) when pushing; do not share your password or tokens. If you upload via GitHub's browser, verify `.github/workflows/build-apk.yml` was included. No APK is available before the first **successful** workflow run.

**Build status:** This project and workflow were prepared without a running Android SDK or GitHub Actions run in this environment. The workflow is configured but compilation and device behavior are not yet verified.

## Build from source

Requires Android Studio (with Android SDK Platform 35) and JDK 17+ (Android Studio's bundled JDK is fine). The project uses Android Gradle Plugin 8.7.3 and supports Android 10 (API 29) or later. Internet access is needed by the build environment to download Gradle/plugins the first time.

1. Extract the project ZIP and open the inner `SushiCamera/` folder in **Android Studio** (File > Open).
2. Let Android Studio install Platform SDK 35 and sync Gradle. If your IDE cannot sync because the wrapper is missing, run `gradle wrapper --gradle-version 8.9` from the project directory with a locally installed Gradle, or configure Android Studio to use local Gradle.
3. In Android Studio, **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Find the APK at `app/build/outputs/apk/debug/app-debug.apk` and install it on the phone, granting camera and optionally microphone permissions.
5. Camera photos/videos appear in `DCIM/SushiCamera`. Tap the gear icon > **Default camera settings** to inspect available system settings.

On Linux with Android SDK, Java and Gradle configured, the command is:

```sh
gradle :app:assembleDebug
```

### Android defaults and shortcuts

- Camera intents: `android.media.action.STILL_IMAGE_CAMERA`, `android.media.action.VIDEO_CAMERA`, `android.media.action.IMAGE_CAPTURE`, `android.media.action.VIDEO_CAPTURE`.
- On Android 11+, implicit capture requests generally use preinstalled system camera apps. This is not fixable just by adding more manifest filters or asking for dangerous permissions. Apps may use an explicit component/package Intent to launch Sushi Camera.
- On compatible phones, Settings > Apps > Default apps may offer a Camera entry or other selection affordance. Xiaomi/HyperOS frequently does not offer an interchangeable default camera for all integrations. You can place Sushi Camera on your home screen or use launcher shortcuts normally.

## Architecture

`MainActivity.java`: responsive controls, settings dialog, permission prompts, capture intent return, persistent preferences.

`CameraEngine.java`: dedicated camera handler thread, Camera2 capture sessions, JPEG ImageReader, MediaRecorder video, MediaStore saves and URI return, hardware capability checks.

No third-party libraries. Source is intended to be modified and device-tested.

## References

- Google Play: https://play.google.com/store/apps/details?id=com.rawcam.app
- Android camera intents: https://developer.android.com/guide/components/intents-common#Camera
- Android Camera2 capture sessions: https://developer.android.com/media/camera/camera2/capture-sessions-requests
- Android 16 compatibility requirements: https://source.android.com/docs/compatibility/16/android-16-cdd
